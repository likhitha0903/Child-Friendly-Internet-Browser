import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pool from "../db";

const app = express();
app.use(express.json());

// CORS Middleware
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  next();
});

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret";

// ---------------------------------------- Authentication Routes ----------------------------------------

// ✅ Parent Registration Route
app.post("/parent-register", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { email, password, role } = req.body;

    if (!email || !password || !role) {
      return res.status(400).json({ error: "All fields are required." });
    }

    // Check if user exists
    const existingUser = await client.query(
      "SELECT * FROM users WHERE email = $1",
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: "User  already exists." });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user
    const result = await client.query(
      "INSERT INTO users (email, password, role) VALUES ($1, $2, $3) RETURNING id, email, role",
      [email, hashedPassword, role]
    );

    const user = result.rows[0];

    // Generate JWT
    const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, {
      expiresIn: "24h",
    });

    return res.status(201).json({ user, token });
  } catch (error) {
    console.error("Registration error:", error);
    return res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release(); // Ensure client is released
  }
});

// ✅  Child Registeration Route
app.post("/child-register", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { parentEmail, email, password, role } = req.body;

 
    if (!parentEmail || !email || !password || !role) {
      console.log("All fields are required.");
      return res.status(400).json({ error: "All fields are required." });
    }

    // Check if user exists
    const existingUser = await client.query(
      "SELECT * FROM public.child WHERE email = $1",
      [email]
    );

    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: "User  already exists." });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user
    const result = await client.query(
      "INSERT INTO public.child (email, password, parent_email, role) VALUES ($1, $2, $3, $4) RETURNING id, email, parent_email, role",
      [email, hashedPassword, parentEmail, role]
    );

    // console.log(result.rows);

    const user = result.rows[0];

    // Generate JWT
    const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, {
      expiresIn: "24h",
    });

    return res.status(201).json({ user, token });
  } catch (error) {
    console.error("Registration error:", error);
    return res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release(); // Ensure client is released
  }
});

// ✅ Login Route
app.post("/login", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res
        .status(400)
        .json({ error: "Email and password are required." });
    }

    // Check if user already exists in the child table
    const result = await client.query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);

    // If no user found in the child table, check the users table
    let existingUser = null;
    if (result.rows.length === 0) {
      existingUser = await client.query(
        "SELECT * FROM child WHERE email = $1",
        [email]
      );
    } else {
      existingUser = result; // If found in child, no need to check users
    }
    if (existingUser.rows.length === null) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const user = existingUser.rows[0];

    // Validate password
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    // Generate JWT
    const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, {
      expiresIn: "24h",
    });

    return res.json({
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        parentEmail: user.parent_email || null,
      },
      token,
    });
  } catch (error) {
    console.error("Login error:", error);
    return res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release(); // Ensure client is released
  }
});

// ---------------------------------------- Ristricted Websites ----------------------------------------

// ✅ Post Websites Route
app.post("/api/websites", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { url, title, parentId } = req.body;

    if (!url || !title || !parentId) {
      return res
        .status(400)
        .json({ error: "URL, title, and parent ID are required." });
    }

    const result = await client.query(
      "INSERT INTO public.websites (title, url, parent_id) VALUES ($1, $2, $3) RETURNING title, url, parent_id",
      [title, url, parentId]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error("Error posting website:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release(); // Ensure client is released
  }
});

// ✅ Get Websites Route
app.get("/api/websites", async (req, res) => {
  const client = await pool.connect();
  try {
    const { parentId } = req.query;
    const result = await client.query(
      "SELECT * FROM public.websites WHERE parent_id = $1",
      [parentId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching websites:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release(); // Ensure client is released
  }
});

// ✅ Delete Websites Route
app.delete("/api/websites", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { id } = req.query;

    // Check if the id is provided
    if (!id) {
      return res.status(400).json({ error: "ID is required." });
    }

    // Execute the DELETE query
    const result = await client.query(
      "DELETE FROM public.websites WHERE id = $1 ",
      [id]
    );

    // Check if any rows were deleted
    if (result.rowCount === 0) {
      return res.status(404).json({ error: "Website not found." });
    }

    res.json({ message: "Website deleted." });
  } catch (error) {
    console.error("Error deleting website:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release(); // Ensure client is released
  }
});

// ---------------------------------------- Child Routes ----------------------------------------

// ✅ Get all Children
app.get("/children", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { email } = req.query;

    if (!email) {
      return res.status(400).json({ error: "Parent email is required." });
    }

    const result = await client.query(
      "SELECT * FROM child WHERE parent_email = $1",
      [email]
    );

    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ error: "No children found for this parent." });
    }

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching children:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release();
  }
});

// ---------------------------------------- For Safe Browsing ----------------------------------------

// ✅ Get Restricted Websites
app.get("/safe-browsing", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { parentEmail } = req.query;
    // console.log("parentEmail", parentEmail);
    const result = await client.query(
      "SELECT w.* FROM websites w JOIN users u ON w.parent_id = u.id JOIN child c ON u.email = c.parent_email WHERE c.parent_email = $1 ",
      [parentEmail]
    );
    // console.log("result", result.rows);
    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching websites:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release();
  }
});

// ✅ Post Browser History
app.post("/browser-history", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { url, childId, title } = req.body;

    if (!url || !childId || !title) {
      return res
        .status(400)
        .json({ error: "URL, child ID, and title are required." });
    }

    const result = await client.query(
      "INSERT INTO public.browsing_history (child_id, url, title) VALUES ($1, $2, $3) RETURNING *",
      [childId, url, title]
    );

    if (result.rows.length > 0) {
      // console.log("Browser history added successfully.");
      res.json({ message: "Browser history added successfully." });
    } else {
      // console.log("Failed to add browser history.");
      res.status(500).json({ error: "Failed to add browser history." });
    }
  } catch (error) {
    // console.error("Error posting browser history:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release();
  }
});

// ✅ Get Browser History
app.get("/browsing-history", async (req: any, res: any) => {
  const client = await pool.connect();
  try {
    const { childId } = req.query;

    if (!childId) {
      return res.status(400).json({ error: "Child ID is required." });
    }

    const result = await client.query(
      "SELECT * FROM public.browsing_history WHERE child_id = $1 ORDER BY visited_at DESC",
      [childId]
    );

    if (result.rows.length === 0) {
      return res
        .status(404)
        .json({ error: "No browsing history found for this child." });
    }

    res.json(result.rows);
  } catch (error) {
    console.error("Error fetching browsing history:", error);
    res.status(500).json({ error: "Internal server error." });
  } finally {
    client.release();
  }
});

//------------------------------------------------------------------------------------------------------------

// ✅ Start the Server
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
