import React from "react";
import { useNavigate } from "react-router-dom";
import { LearningMaterial } from "../types";

const learningMaterials: LearningMaterial[] = [
  {
    id: 1,
    title: "ABC Songs for Kids",
    type: "video",
    url: "https://www.youtube.com/watch?v=75p-N9YKqNo",
    thumbnail: "https://img.youtube.com/vi/75p-N9YKqNo/hqdefault.jpg",
  },
  {
    id: 2,
    title: "Math Learning Game",
    type: "game",
    url: "https://www.coolmathgames.com/",
    thumbnail:
      "https://www.coolmathgames.com/themes/custom/coolmath/logo-small-stacked.svg",
  },
  {
    id: 3,
    title: "National Geographic Kids",
    type: "website",
    url: "https://kids.nationalgeographic.com/",
    thumbnail:
      "https://i.natgeofe.com/n/9809eae8-2750-4ecf-9d48-1de552cf0f78/kids.png?wp=1&w=265.5&h=112.5", // Fixed Thumbnail
  },
  {
    id: 4,
    title: "Learn Good Manners for Kids",
    type: "video",
    url: "https://www.youtube.com/watch?v=T7ly5H1k9gM",
    thumbnail: "https://img.youtube.com/vi/T7ly5H1k9gM/hqdefault.jpg",
  },
  {
    id: 5,
    title: "Fun Coding for Kids",
    type: "website",
    url: "https://www.code.org/",
    thumbnail: "https://code.org/images/logo.svg",
  },
  {
    id: 6,
    title: "Interactive Science Experiments",
    type: "website",
    url: "https://www.sciencefun.org/kidszone/experiments/",
    thumbnail:
      "https://www.sciencefun.org/wp-content/uploads/2012/12/l_sffe-logo.png",
  },
];

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-100 to-blue-300">
      {/* 🌟 Navbar */}
      <nav className="flex justify-between items-center px-8 py-4 bg-white shadow-md">
        <h1 className="text-2xl font-bold text-blue-600">
          Kids Learning Hub 🎓
        </h1>
        <div>
          <button
            onClick={() => navigate("/login")}
            className="mr-4 px-6 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600 transition"
          >
            Login
          </button>
          <button
            onClick={() => navigate("/register")}
            className="px-6 py-2 bg-green-500 text-white font-semibold rounded-md hover:bg-green-600 transition"
          >
            Register
          </button>
        </div>
      </nav>

      {/* 🚀 Hero Section */}
      <header className="text-center py-16 px-6">
        <h2 className="text-4xl font-extrabold text-blue-700">
          Learn & Play in a Fun Way! 🎮📚
        </h2>
        <p className="text-lg text-gray-700 mt-3 max-w-2xl mx-auto">
          Explore fun educational games, exciting YouTube learning videos, and
          interactive websites made for kids! 🚀
        </p>
        <button
          onClick={() => navigate("/login")}
          className="mt-6 px-6 py-3 bg-purple-500 text-white font-semibold rounded-md hover:bg-purple-600 transition"
        >
          Start Learning Now
        </button>
      </header>

      {/* 📚 Learning Materials Section */}
      <div className="max-w-5xl mx-auto px-4 py-10">
        <h2 className="text-3xl font-semibold text-center text-blue-700 mb-6">
          Explore Learning Resources
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {learningMaterials.map((material) => (
            <div
              key={material.id}
              className="bg-white rounded-lg shadow-lg p-4 hover:shadow-xl transition transform hover:-translate-y-1"
            >
              <img
                src={material.thumbnail}
                alt={material.title}
                className="w-full h-40 object-cover rounded-md"
              />
              <h3 className="text-lg font-semibold text-gray-800 mt-3">
                {material.title}
              </h3>
              <p
                className={`text-sm font-medium ${
                  material.type === "video"
                    ? "text-red-500"
                    : material.type === "game"
                    ? "text-green-500"
                    : "text-blue-500"
                }`}
              >
                {material.type.toUpperCase()}
              </p>
              <a
                href={material.url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 block text-center bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 rounded-md transition"
              >
                Explore →
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* 🌍 Footer */}
      <footer className="bg-blue-600 text-white text-center py-4 mt-10">
        <p>© 2025 Kids Learning Hub. All Rights Reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;
