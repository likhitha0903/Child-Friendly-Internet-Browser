import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Lock, Mail, User } from "lucide-react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const Register = () => {
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const [email, setEmail] = useState("");
  const [parentEmail, setParentEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState<"parent" | "child">("parent");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    try {
      if (role === "parent") {
        const response = await axios.post(
          "http://localhost:5000/parent-register",
          {
            email,
            password,
            role,
          }
        );
        const { user } = response.data;
        setUser(user);
        navigate("/parent-dashboard");
      }

      if (role === "child" && parentEmail) {
        const response = await axios.post(
          "http://localhost:5000/child-register",
          {
            parentEmail,
            email,
            password,
            role,
          }
        );

        // console.log("response", response.data.user);

        const { user } = response.data;
        setUser(user);
        navigate("/child-dashboard");
      }

      // navigate(role === "parent" ? "/parent-dashboard" : "/child-dashboard");
      // localStorage.setItem("token", token);
    } catch (err) {
      setError("Registration failed. Please try again.");
      console.error("Registration error:", err);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md w-96">
        <div className="flex justify-center mb-6">
          <User className="h-12 w-12 text-blue-500" />
        </div>
        <h2 className="text-2xl font-bold text-center mb-6">Create Account</h2>
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Role
            </label>
            <div className="mt-1 flex space-x-4">
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  value="parent"
                  checked={role === "parent"}
                  onChange={(e) =>
                    setRole(e.target.value as "parent" | "child")
                  }
                  className="form-radio text-blue-500"
                />
                <span className="ml-2">Parent</span>
              </label>
              <label className="inline-flex items-center">
                <input
                  type="radio"
                  value="child"
                  checked={role === "child"}
                  onChange={(e) =>
                    setRole(e.target.value as "parent" | "child")
                  }
                  className="form-radio text-blue-500"
                />
                <span className="ml-2">Child</span>
              </label>
            </div>
          </div>
          {role === "child" && (
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
              <input
                type="email"
                value={parentEmail}
                onChange={(e) => setParentEmail(e.target.value)}
                placeholder="Parents Email"
                className="pl-10 w-full p-2 border rounded-md"
                required
              />
            </div>
          )}

          <div className="relative">
            <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="pl-10 w-full p-2 border rounded-md"
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="pl-10 w-full p-2 border rounded-md"
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm Password"
              className="pl-10 w-full p-2 border rounded-md"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition-colors"
          >
            Create Account
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-gray-600">
          Already have an account?{" "}
          <Link to="/login" className="text-blue-500 hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
