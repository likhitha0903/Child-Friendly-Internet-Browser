import React, { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import Navbar from "./Navbar";
import { useAuth } from "../context/AuthContext";
import axios from "axios";
import { useWebsites } from "../context/WebsiteContext";
import BrowsingHistory from "./BrowsingHistory";

const ParentDashboard: React.FC = () => {
  const { user } = useAuth();
  const { websites, setWebsites } = useWebsites();
  const [newUrl, setNewUrl] = useState<string>("");
  const [newTitle, setNewTitle] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [message, setMessage] = useState<string>(""); // State for message display

  const fetchWebsites = async () => {
    try {
      console.log("Fetching websites");
      const response = await axios.get(`http://localhost:5000/api/websites`, {
        params: {
          parentId: user?.id,
        },
      });

      if (response.status === 200) {
        setWebsites(response.data);
      } else {
        console.error("Failed to fetch websites:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching websites:", error);
    }
  };

  const handleAddWebsite = async () => {
    setLoading(true);
    if (newUrl && newTitle && user) {
      try {
        const response = await axios.post(
          "http://localhost:5000/api/websites",
          {
            url: newUrl,
            title: newTitle,
            parentId: user.id,
          }
        );

        console.log("Added website:", response.data);
        setWebsites([...websites, response.data]);
        setMessage("Website added successfully!"); // Set success message
        setLoading(false);
        setNewUrl("");
        setNewTitle("");

        // Clear message after 3 seconds
        setTimeout(() => {
          setMessage("");
        }, 3000);
      } catch (error) {
        console.error("Parent Dashboard Error:", error);
        setMessage("Failed to add website."); // Set error message
        setLoading(false);

        // Clear message after 3 seconds
        setTimeout(() => {
          setMessage("");
        }, 3000);
      }
    }
  };

  const handleDeleteWebsite = async (id: string) => {
    try {
      const response = await axios.delete(
        `http://localhost:5000/api/websites`,
        {
          params: {
            id: id,
          },
        }
      );

      console.log("Deleted website:", response.data.message);
      setWebsites(websites.filter((website) => website.id !== id));
      setMessage("Website deleted successfully!"); // Set success message

      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage("");
      }, 3000);
    } catch (error) {
      console.error("Error deleting website:", error);
      setMessage("Failed to delete website."); // Set error message

      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage("");
      }, 3000);
    }
  };

  useEffect(() => {
    if (user && user.id) {
      fetchWebsites();
    }
  }, [user, handleAddWebsite, handleDeleteWebsite]);

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Add Unsafe Websites</h2>
            <div className="flex gap-4">
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Website Title"
                className="flex-1 p-2 border rounded-md"
              />
              <input
                type="url"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                placeholder="Website URL"
                className="flex-1 p-2 border rounded-md"
              />
              <button
                onClick={handleAddWebsite}
                className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors flex items-center"
              >
                {loading ? (
                  "Adding..."
                ) : (
                  <>
                    <Plus className="h-5 w-5 mr-2" />
                    Add
                  </>
                )}
              </button>
            </div>
            {message && (
              <div className="mt-4 text-green-500">{message}</div> // Display message
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {websites.length !== 0 ? (
              websites.map((website) => (
                <div
                  key={website.id}
                  className="bg-white rounded-lg shadow-md p-6"
                >
                  <h3 className="text-lg font-semibold mb-2">
                    {website.title}
                  </h3>
                  <a
                    href={website.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-500 hover:underline break-all"
                  >
                    {website.url}
                  </a>
                  <button
                    onClick={() => handleDeleteWebsite(website.id)}
                    className="mt-4 text-red-500 hover:text-red-600 transition-colors flex items-center"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remove
                  </button>
                </div>
              ))
            ) : (
              <div className="bg-white rounded-lg shadow-md p-6">
                No websites added yet
              </div>
            )}
          </div>
        </div>
        <div className="w-full h-[2px] bg-neutral-200 my-5"></div>
        {/* Browsing History */}
        <h2 className="text-4xl text-center font-semibold text-gray-800 mb-4 self-center">
          Browsing History
        </h2>
        <BrowsingHistory />
      </div>
    </div>
  );
};

export default ParentDashboard;
