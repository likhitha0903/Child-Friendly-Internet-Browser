import React, { useState, useEffect } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
// import { Link } from "react-router-dom";

interface Child {
  id: string;
  email: string;
}

interface BrowsingHistoryItem {
  url: string;
  title: string;
  visited_at: string;
}

const BrowsingHistory: React.FC = () => {
  const { user } = useAuth();
  const [children, setChildren] = useState<Child[]>([]);
  const [selectedChild, setSelectedChild] = useState<string>("");
  const [browsingHistory, setBrowsingHistory] = useState<BrowsingHistoryItem[]>(
    []
  );

  useEffect(() => {
    const fetchChildren = async () => {
      try {
        const response = await axios.get("http://localhost:5000/children", {
          params: {
            email: user?.email,
          },
        });
        setChildren(response.data);
        console.log("Children:", response.data);
      } catch (error) {
        console.error("Error fetching children:", error);
      }
    };
    fetchChildren();
  }, []);

  useEffect(() => {
    const fetchBrowsingHistory = async () => {
      setBrowsingHistory([]);
      if (selectedChild) {
        try {
          const response = await axios.get(
            `http://localhost:5000/browsing-history`,
            {
              params: {
                childId: selectedChild,
              },
            }
          );
          setBrowsingHistory(response.data);
          console.log("Browsing history:", response.data);
        } catch (error) {
          console.error("Error fetching browsing history:", error);
        }
      }
    };
    fetchBrowsingHistory();
  }, [selectedChild]);

  const handleSelectChild = (childId: string) => {
    setSelectedChild(childId);
  };

  return (
    <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-6 mt-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Select a Child
      </h2>
      <select
        value={selectedChild}
        onChange={(e) => handleSelectChild(e.target.value)}
        className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none"
      >
        <option value="">Select a child</option>
        {children.length === 0 ? (
          <option value="" disabled>
            {" "}
            No Child Connected
          </option>
        ) : (
          children.map((child) => (
            <option key={child.id} value={child.id}>
              {child.email}
            </option>
          ))
        )}
        {}
      </select>

      {selectedChild && (
        <div className="mt-6">
          <h2 className="text-xl font-semibold text-gray-800">
            Browsing History for{" "}
            <span className="text-blue-500">
              {children.find((child) => child.id === selectedChild)?.email}
            </span>
          </h2>

          <div className="overflow-x-auto mt-4 bg-gray-50 rounded-lg shadow-md">
            <table className="min-w-full border border-gray-200 rounded-lg">
              <thead>
                <tr className="bg-blue-500 text-white uppercase text-sm leading-normal">
                  <th className="py-3 px-6 text-left">Website</th>
                  <th className="py-3 px-6 text-left">Website Link</th>
                  <th className="py-3 px-6 text-left">Visited At</th>
                </tr>
              </thead>
              <tbody className="text-gray-700 text-sm">
                {browsingHistory.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-3 px-6 text-center">
                      No browsing history found
                    </td>
                  </tr>
                ) : (
                  browsingHistory.map((item, index) => (
                    <tr
                      onClick={() => window.open(item.url, "_blank")}
                      key={index}
                      className="border-b border-gray-200 hover:bg-blue-100 transition cursor-pointer"
                    >
                      <td className="py-3 px-6">
                        {/* <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        > */}
                        {item.title}
                        {/* </a> */}
                      </td>
                      <td className="py-3 px-6">
                        {/* <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        > */}
                        {item.url}
                        {/* </a> */}
                      </td>
                      <td className="py-3 px-6 text-gray-500">
                        {item.visited_at}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default BrowsingHistory;
