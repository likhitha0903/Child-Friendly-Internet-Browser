import React, { useEffect, useState } from "react";
import { Search } from "lucide-react";
import type { SearchResult } from "../types";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import axios from "axios";

// interface SearchResult {
//   position: number;
//   url: string;
//   title: string;
//   description: string;
// }

const ChildDashboard: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [restrictedUrls, setRestrictedUrls] = useState<string[]>([]); // Store restricted URLs
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  // console.log("user", user?.parent_email);

  const fetchRestrictedUrls = async () => {
    // console.log("user?.parentEmail:", user?.parentEmail); // Debugging line
    try {
      const response = await axios.get(`http://localhost:5000/safe-browsing`, {
        params: {
          parentEmail: user?.parent_email,
        },
      });

      // Assuming response.data is an array of objects with a 'url' property
      const restrictedUrls = response.data.map((item: any) => item.url);
      setRestrictedUrls(restrictedUrls.map((url: string) => String(url))); // Ensure all URLs are strings
      // console.log("Restricted URLs:", restrictedUrls); // Debugging line
    } catch (error) {
      console.error("Error fetching websites:", error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(
        `https://google-search74.p.rapidapi.com/?query=${encodeURIComponent(
          searchQuery
        )}&limit=10&related_keywords=true`,
        {
          headers: {
            "x-rapidapi-key":
              "904922e3cbmsh9f93e45ab5c1ea0p1778e7jsna43a51752189",
            "x-rapidapi-host": "google-search74.p.rapidapi.com",
          },
        }
      );

      const data = await response.json();
      console.log("Search results:", data.results); // Debugging line

      // Filter out restricted URLs from the search results
      const filteredResults = data.results.filter((result: SearchResult) => {
        return !restrictedUrls.some((url) => result.url.includes(url));
      });

      console.log("Filtered Search Results:", filteredResults); // Debugging line
      setSearchResults(filteredResults);
    } catch (error) {
      console.error("Search error:", error);
    } finally {
      setLoading(false);
    }
  };

  const storeBrowserHistory = async (url: string, title: string) => {
    try {
      await axios.post("http://localhost:5000/browser-history", {
        url,
        title,
        childId: user?.id,
      });
    } catch (error) {
      console.error("Error storing browser history:", error);
    }
  };

  const handleLinkClick = (url: string, title: string) => {
    storeBrowserHistory(url, title); // Store the browsing history
    // console.log("Link clicked:", url, title); // Debugging line
  };

  useEffect(() => {
    fetchRestrictedUrls();
  }, [user, handleSearch]);

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <div className="p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex gap-4">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for kid-friendly content..."
                className="flex-1 p-2 border rounded-md"
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              />
              <button
                onClick={handleSearch}
                disabled={loading}
                className="bg-blue-500 text-white px-6 py-2 rounded-md hover:bg-blue-600 transition-colors flex items-center"
              >
                <Search className="h-5 w-5 mr-2" />
                {loading ? "Searching..." : "Search"}
              </button>
            </div>
          </div>

          <div className="space-y-6">
            {searchResults.map((result, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <Link
                  to={result.url}
                  onClick={() => handleLinkClick(result.url, result.title)}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <h2 className="text-xl font-semibold mb-2">{result.title}</h2>
                  <p className="text-gray-600">{String(result.description)}</p>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChildDashboard;
