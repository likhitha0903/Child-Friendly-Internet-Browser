export interface User {
  id: string;
  email: string;
  parent_email: string | null;
  role: "parent" | "child";
}

export interface Website {
  id: string;
  url: string;
  title: string;
  parentId: string;
}

export interface SearchResult {
  title: string;
  // link: string;
  position: number;
  url: string;
  description: string;
}

export interface LearningMaterial {
  id: number;
  title: string;
  type: "video" | "game" | "website";
  url: string;
  thumbnail: string;
}
