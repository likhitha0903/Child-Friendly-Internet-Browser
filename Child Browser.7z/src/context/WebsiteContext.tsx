import React, { createContext, useContext, useState } from "react";
import { Website } from "../types";

// Define the type for a website
// interface Website {
//   id: number; // Adjust based on your database schema
//   title: string;
//   url: string;
//   parent_id: number; // Adjust based on your schema
// }

// Define the context type
interface WebsitesContextType {
  websites: Website[];
  setWebsites: (websites: Website[]) => void;
}

// Create the context
const WebsitesContext = createContext<WebsitesContextType | undefined>(
  undefined
);

// Create the provider component
export const WebsitesProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [websites, setWebsites] = useState<Website[]>([]);

  // Function to fetch websites from the API

  return (
    <WebsitesContext.Provider value={{ websites, setWebsites }}>
      {children}
    </WebsitesContext.Provider>
  );
};

// Create a custom hook to use the context
export const useWebsites = () => {
  const context = useContext(WebsitesContext);
  if (context === undefined) {
    throw new Error("useWebsites must be used within a WebsitesProvider");
  }
  return context;
};
