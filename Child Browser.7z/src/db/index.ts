import pg from "pg";
const { Pool } = pg;

const pool = new Pool({
  connectionString:
    "postgresql://neondb_owner:npg_84DhapLQRFAb@ep-little-hat-a8b1ugcl-pooler.eastus2.azure.neon.tech/neondb?sslmode=require",
});

export default pool;
