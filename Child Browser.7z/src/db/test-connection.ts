import pool from "./index"; // Ensure 'index.ts' exports a configured Pool instance from 'pg'

const testConnection = async (): Promise<void> => {
  try {
    const client = await pool.connect();
    console.log("✅ Successfully connected to Neon database!");

    // Test query to verify connection and schema
    const result = await client.query<{
      current_database: string;
      current_user: string;
    }>("SELECT current_database(), current_user");

    console.log("📌 Database:", result.rows[0].current_database);
    console.log("👤 User:", result.rows[0].current_user);

    client.release(); // Release connection back to the pool
  } catch (err) {
    console.error("❌ Database connection error:", err);
  }
};

// Execute the function
testConnection();

export default testConnection;
