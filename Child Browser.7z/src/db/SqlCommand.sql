CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(10) NOT NULL CHECK (role IN ('parent', 'child')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE IF NOT EXISTS websites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title VARCHAR(255) NOT NULL,
    url TEXT NOT NULL,
    parent_id UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );
  
  CREATE TABLE public.child (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      email VARCHAR(255) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      parent_email VARCHAR(255) NOT NULL,
      FOREIGN KEY (parent_email) REFERENCES public.users(email)
     
  );
  
  
  ALTER TABLE public.child ADD COLUMN role VARCHAR(10) CHECK (role IN ('parent', 'child'));
  
  CREATE TABLE browsing_history (
      id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
      child_id UUID NOT NULL,
      url TEXT NOT NULL,
      title VARCHAR(255),
      visited_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (child_id) REFERENCES child(id)
  );
  
  -- Indexes
  CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
  CREATE INDEX IF NOT EXISTS idx_websites_parent_id ON websites(parent_id);
  
  